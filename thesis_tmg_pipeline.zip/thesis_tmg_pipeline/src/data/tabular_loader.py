from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import TensorDataset


def _read_csv(path: Path) -> torch.Tensor:
    if not path.exists():
        raise FileNotFoundError(f"Missing required file: {path}")
    return torch.tensor(pd.read_csv(path).values)


def load_dataset(dataset_name: str, data_root: Path, cache_dir: Path) -> dict:
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"{dataset_name.lower()}_cache.pt"

    if cache_file.exists():
        return torch.load(cache_file, weights_only=False)

    dataset_dir = data_root / dataset_name
    x_train = _read_csv(dataset_dir / "x_train.csv").float()
    y_train = _read_csv(dataset_dir / "y_train.csv")
    x_test = _read_csv(dataset_dir / "x_test.csv").float()
    y_test = _read_csv(dataset_dir / "y_test.csv")

    if y_train.ndim == 2 and y_train.shape[1] > 1:
        y_train = torch.argmax(y_train, dim=1)
    else:
        y_train = y_train.squeeze().long()

    if y_test.ndim == 2 and y_test.shape[1] > 1:
        y_test = torch.argmax(y_test, dim=1)
    else:
        y_test = y_test.squeeze().long()

    payload = {
        "x_train": x_train,
        "y_train": y_train,
        "x_test": x_test,
        "y_test": y_test,
        "input_dim": int(x_train.shape[1]),
        "num_classes": int(torch.max(y_train).item() + 1),
        "train_dataset": TensorDataset(x_train, y_train),
        "test_dataset": TensorDataset(x_test, y_test),
    }

    torch.save(payload, cache_file)
    return payload
